﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mashqlar
{
    class Program
    {
        static void Main(string[] args)
        {
            /* 4-MISOL
            Console.WriteLine("Aylana uzunligini kiriting: ");
            int d;
            d = Convert.ToInt32(Console.ReadLine());
           double L;
            L = Math.PI * d;
            Console.WriteLine(L);
             */

            /*  5-MISOL
            Console.WriteLine("Kub tomoni kiriting: ");
            int a; 
            a = Convert.ToInt32(Console.ReadLine());
            double V,S;
            V = Math.Pow(a, 3);
            Console.WriteLine(V);
            S = Math.Pow(a, 2) * 6;
            Console.WriteLine(S);
             */

            /*  6-MISOL
            Console.WriteLine("TOMONLARINI KIRITING: ");
            int a;
            a = Convert.ToInt32(Console.ReadLine());
            int b;
            b = Convert.ToInt32(Console.ReadLine());
            int c;
            c = Convert.ToInt32(Console.ReadLine());
            int V;
            int S;
            V = a * b * c;
            S=2*(a*b+b*c+c*a);
            Console.WriteLine(V);
            Console.WriteLine(S);
             */

            /*  7-MISOL
            Console.WriteLine("Doira radusini kiriting: ");
            double R;
            R = Convert.ToInt32(Console.ReadLine());
            double L;
            double S;
            L = Math.PI * 2 * R;
            S = Math.PI * Math.Pow(R,2);
            Console.WriteLine(L);
            Console.WriteLine(S);
            */

            /*  8-MISOL
            Console.WriteLine("SONLARNI KIRITING: ");
            double a;
            a = Convert.ToInt32(Console.ReadLine());
            double b;
            b = Convert.ToInt32(Console.ReadLine());
            double M;
            M = (a + b) / 2;
            Console.WriteLine(M);
             */

            /*  9-MISOL
            Console.WriteLine("SONLARNI KIRITING: ");
            double a;
            a = Convert.ToInt32(Console.ReadLine());
            double b;
            b = Convert.ToInt32(Console.ReadLine());
            double M=a*b;
            M = Math.Sqrt(M);
            Console.WriteLine(M);
             */

            /*  10-MISOL
            Console.WriteLine("SONLARNI KIRITING: ");
            double a;
            a = Convert.ToInt32(Console.ReadLine());
            double b;
            b = Convert.ToInt32(Console.ReadLine());
            double Y;
            double K;
            double A;
            double B;
            if (a != 0 && b != 0)
            {
                Y = a + b;
                K = a * b;
                A = Math.Pow(a, 2);
                B = Math.Pow(b, 2);
                Console.WriteLine("YIG'INDISI:" + Y);
                Console.WriteLine("KO'PAYTIMASI:" + K);
                Console.WriteLine("A ning kvadrati: " + A);
                Console.WriteLine("B ning kvadrati: " + B);
            }
            else Console.WriteLine("Sonlar 0 ga teng bo'lmasligi kerak ! ");
            */

            /*  11-MISOL
              Console.WriteLine("SONLARNI KIRITING: ");
            double a;
            a = Convert.ToInt32(Console.ReadLine());
            double b;
            b = Convert.ToInt32(Console.ReadLine());
            double Y;
            double K;
            double A;
            double B;
            if (a != 0 && b != 0)
            {
                Y = a + b;
                K = a * b;
                A = Math.Abs(a);
                B = Math.Abs(b);
                Console.WriteLine("YIG'INDISI:" + Y);
                Console.WriteLine("KO'PAYTIMASI:" + K);
                Console.WriteLine("A ning moduli: " + A);
                Console.WriteLine("B ning moduli: " + B);
            }
            else Console.WriteLine("Sonlar 0 ga teng bo'lmasligi kerak ! ");
            */

            /*  12-MISOL
            Console.WriteLine("SONLARNI KIRITING: ");
            double a;
            a = Convert.ToInt32(Console.ReadLine());
            double b;
            b = Convert.ToInt32(Console.ReadLine());
            double c;
           double P;
           double d;
            d = Math.Pow(a,2) + Math.Pow(b,2);
            c = Math.Sqrt(d);
            P = a + b + c;
            Console.WriteLine("Gipotenuzasi:" + c);
            Console.WriteLine("PERIMETIRI:" + P);
             */
            /* 13-misol
            Console.WriteLine("RADIUSLARNI KIRITING: ");
            double a;
            a = Convert.ToInt32(Console.ReadLine());
            double b;
            b = Convert.ToInt32(Console.ReadLine());
            double S1;
            double S2;
            double S3;
            if (a > b)
            {
                S1 = Math.PI * a;
                S2 = Math.PI * b;
                S3 = Math.PI * (a - b);
                Console.WriteLine("S1 yuza" + S1);
                Console.WriteLine("S2 yuza" + S2);
                Console.WriteLine("S3 yuza" + S3);
            }
            else Console.WriteLine("R1 R2 dan kichkina! Birinchi kattasini kiriting ! ");
             */

            /* 14-misol
            Console.WriteLine("Aylana uzunligini kiriting: ");
            double L;
            L = Convert.ToInt32(Console.ReadLine());
            double R;
            double S;
            R = L / (Math.PI * 2);
            S = Math.PI * Math.Pow(R, 2);
            Console.WriteLine(R);
            Console.WriteLine(S);
             */
            Console.WriteLine("Uzunlikni kiriting (SM da)= ");
            double s=Convert.ToDouble(Console.ReadLine());
            double m;
            m = s/100;
            Console.Write("Uzunlik: "+ m +"metrga teng");
            Console.ReadKey();
        }
    }
}
