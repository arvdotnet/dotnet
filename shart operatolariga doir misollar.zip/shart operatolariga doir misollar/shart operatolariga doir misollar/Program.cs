﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shart_operatolariga_doir_misollar
{
    class Program
    {
        static void Main(string[] args)
        {
            ////Shart operatoplari///////
            /*    9-misol
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            if (a > b)
            {
                Console.WriteLine(a+"soni"+b +"dan katta");
            }
            if (b > a)
            {
                Console.WriteLine(b + "soni " + a + " dan katta");
            }
            else Console.WriteLine("Ikkisi ham teng");
             */

            /*   10-misol
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            if (a != b)
            {
                Console.WriteLine("Javob= " + (a + b));
            }
           if (a==b)
           {
               Console.WriteLine(0);
           }
             */
            /*  12-misol
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            int c = Convert.ToInt32(Console.ReadLine());
            if (a > b & b > c || a < b & b > c)
            {
                Console.WriteLine(c);
            }
            if (a < b & b < c || a < b & b > c)
            {
                Console.WriteLine(a);
            }
            if (a > b & b < c || a > b & b < c)
            {
                Console.WriteLine(b);
            }
           */
            
            /*  17-misol
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            int c = Convert.ToInt32(Console.ReadLine());
            if (a > b & b > c || b > a & a > c || c > b & b > a)
            {
                int d = 2 * a; int e = 2 * b; int f = 2 * c;
                Console.WriteLine(d);
                Console.WriteLine(e);
                Console.WriteLine(f);
            }
            else 
                Console.WriteLine(-a);
                Console.WriteLine(-b);
                Console.WriteLine(-c);
             */

            /*      22-misol
            int x = Convert.ToInt32(Console.ReadLine());
            int y = Convert.ToInt32(Console.ReadLine());
            if (x > 0 & y > 0)
            
                {
                    Console.WriteLine("Kordinataning I choragida joylashgan");
                }
                if (x < 0 & y > 0)
                {
                    Console.WriteLine("Kordinataning II choragida joylashgan");
                }
                if (x < 0 & y < 0)
                {
                    Console.WriteLine("Kordinataning III choragida joylashgan");
                }
                if (x > 0 & y < 0)
                {
                    Console.WriteLine("Kordinataning IV choragida joylashgan");
                }

                if (x == 0 || y == 0)
                {
                    Console.WriteLine("Kordinata o'qlarida joylashgan");
                }
             */
            /*   23-misol
            Console.Write("x1= ");
            int x1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("y1= ");
            int y1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("x2= ");
            int x2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("y2= ");
            int y2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("x3= ");
            int x3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("y3= ");
            int y3 = Convert.ToInt32(Console.ReadLine());
            int x4;
            int y4;
            x4 = x1;
            y4 = y3;
            Console.WriteLine("X4= "+x1+"Y4= "+y3);
            */

            /*    24-misol
            int x=Convert.ToInt32(Console.ReadLine());
            if (x > 0)
            {
              Console.WriteLine(2 * Math.Sin(x));
            }
            if (x <= 0)
            {
                Console.WriteLine(x-6);
            }
             */
            /*  25-misol
            int x = Convert.ToInt32(Console.ReadLine());
            if (x < -2 || x > 2)
            {
                Console.WriteLine("Javob= " + 2 * x);
            }
            else Console.WriteLine("Javob= "+-3*x);
             */

            /*   28-misol
            int x=Convert.ToInt32(Console.ReadLine());
            if (x % 4 == 0)
            {
                Console.WriteLine("Bu yilda 366 kun bor");
            }
            else Console.WriteLine("Bu yilda 365 kun bor");
             ///hatolik bo'lishi mumkin//////
             */

            ///   30-misol     ////
            int x=Convert.ToInt32(Console.ReadLine());

            if (x % 2 == 0 && x >= 10 && x <= 98)
            {
                Console.WriteLine("Bu son IKKI XONALI JUFT SON ");
            }
            else if (x % 2 != 0 && x >= 10 && x <= 99)
            {
                Console.WriteLine("Bu son IKKI XONALI TOQ SON ");
            }
            else if (x % 2 == 0 && x >= 100 && x <= 998)
            {
                Console.WriteLine("Bu son UCH XONALI JUFT SON ");
            }
            else if (x % 2 != 0 && x >= 101 && x <= 999)
            {
                Console.WriteLine("Bu son UCH XONALI TOQ SON ");
            }
            else if (x % 2 == 0 && x < 10 && x >= 0)
            {
                Console.WriteLine("Bu son bir XONALI JUFT SON ");
            }
            else if (x % 2 != 0 && x < 10 && x > 0)
            {
                Console.WriteLine("Bu son bir XONALI TOQ SON ");
            }
             
            Console.ReadKey();
        }
    }
}
